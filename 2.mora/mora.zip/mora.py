a=list(map(int, input().split()))
b=list(map(int, input().split()))
c=list(map(int, input().split()))
d=list(map(int, input().split()))
e=list(map(int, input().split()))
f=list(map(int, input().split()))
g=list(map(int, input().split()))
h=list(map(int, input().split()))
i=list(map(int, input().split()))
j=list(map(int, input().split()))
# 1 剪刀 2 石頭 3 布

#假設A贏，則顯示 The first man wins the game
#假設B贏，則顯示 The second man wins the game
#假設平手，則顯示 A tie

if (a[0]==1) & (a[1]==1):
    print("A tie")
elif(a[0]==1) & (a[1]==2):
    print("The second man wins the game")
elif(a[0]==1) & (a[1]==3):
    print("The first man wins the game")
elif(a[0]==2) & (a[1]==1):
    print("The first man wins the game")
elif(a[0]==2) & (a[1]==2):
    print("A tie")
elif(a[0]==2) & (a[1]==3):
    print("The second man wins the game")
elif(a[0]==3) & (a[1]==1):
    print("The second man wins the game")
elif(a[0]==3) & (a[1]==2):
    print("The first man wins the game")
elif(a[0]==3) & (a[1]==3):
    print("A tie")

# 處理 b 組
if (b[0]==1) & (b[1]==1):
    print("A tie")
elif(b[0]==1) & (b[1]==2):
    print("The second man wins the game")
elif(b[0]==1) & (b[1]==3):
    print("The first man wins the game")
elif(b[0]==2) & (b[1]==1):
    print("The first man wins the game")
elif(b[0]==2) & (b[1]==2):
    print("A tie")
elif(b[0]==2) & (b[1]==3):
    print("The second man wins the game")
elif(b[0]==3) & (b[1]==1):
    print("The second man wins the game")
elif(b[0]==3) & (b[1]==2):
    print("The first man wins the game")
elif(b[0]==3) & (b[1]==3):
    print("A tie")

# 處理 c 組
if (c[0]==1) & (c[1]==1):
    print("A tie")
elif(c[0]==1) & (c[1]==2):
    print("The second man wins the game")
elif(c[0]==1) & (c[1]==3):
    print("The first man wins the game")
elif(c[0]==2) & (c[1]==1):
    print("The first man wins the game")
elif(c[0]==2) & (c[1]==2):
    print("A tie")
elif(c[0]==2) & (c[1]==3):
    print("The second man wins the game")
elif(c[0]==3) & (c[1]==1):
    print("The second man wins the game")
elif(c[0]==3) & (c[1]==2):
    print("The first man wins the game")
elif(c[0]==3) & (c[1]==3):
    print("A tie")

# 處理 d 組
if (d[0]==1) & (d[1]==1):
    print("A tie")
elif(d[0]==1) & (d[1]==2):
    print("The second man wins the game")
elif(d[0]==1) & (d[1]==3):
    print("The first man wins the game")
elif(d[0]==2) & (d[1]==1):
    print("The first man wins the game")
elif(d[0]==2) & (d[1]==2):
    print("A tie")
elif(d[0]==2) & (d[1]==3):
    print("The second man wins the game")
elif(d[0]==3) & (d[1]==1):
    print("The second man wins the game")
elif(d[0]==3) & (d[1]==2):
    print("The first man wins the game")
elif(d[0]==3) & (d[1]==3):
    print("A tie")

# 處理 e 組
if (e[0]==1) & (e[1]==1):
    print("A tie")
elif(e[0]==1) & (e[1]==2):
    print("The second man wins the game")
elif(e[0]==1) & (e[1]==3):
    print("The first man wins the game")
elif(e[0]==2) & (e[1]==1):
    print("The first man wins the game")
elif(e[0]==2) & (e[1]==2):
    print("A tie")
elif(e[0]==2) & (e[1]==3):
    print("The second man wins the game")
elif(e[0]==3) & (e[1]==1):
    print("The second man wins the game")
elif(e[0]==3) & (e[1]==2):
    print("The first man wins the game")
elif(e[0]==3) & (e[1]==3):
    print("A tie")

# 處理 f 組
if (f[0]==1) & (f[1]==1):
    print("A tie")
elif(f[0]==1) & (f[1]==2):
    print("The second man wins the game")
elif(f[0]==1) & (f[1]==3):
    print("The first man wins the game")
elif(f[0]==2) & (f[1]==1):
    print("The first man wins the game")
elif(f[0]==2) & (f[1]==2):
    print("A tie")
elif(f[0]==2) & (f[1]==3):
    print("The second man wins the game")
elif(f[0]==3) & (f[1]==1):
    print("The second man wins the game")
elif(f[0]==3) & (f[1]==2):
    print("The first man wins the game")
elif(f[0]==3) & (f[1]==3):
    print("A tie")

# 處理 g 組
if (g[0]==1) & (g[1]==1):
    print("A tie")
elif(g[0]==1) & (g[1]==2):
    print("The second man wins the game")
elif(g[0]==1) & (g[1]==3):
    print("The first man wins the game")
elif(g[0]==2) & (g[1]==1):
    print("The first man wins the game")
elif(g[0]==2) & (g[1]==2):
    print("A tie")
elif(g[0]==2) & (g[1]==3):
    print("The second man wins the game")
elif(g[0]==3) & (g[1]==1):
    print("The second man wins the game")
elif(g[0]==3) & (g[1]==2):
    print("The first man wins the game")
elif(g[0]==3) & (g[1]==3):
    print("A tie")

# 處理 h 組
if (h[0]==1) & (h[1]==1):
    print("A tie")
elif(h[0]==1) & (h[1]==2):
    print("The second man wins the game")
elif(h[0]==1) & (h[1]==3):
    print("The first man wins the game")
elif(h[0]==2) & (h[1]==1):
    print("The first man wins the game")
elif(h[0]==2) & (h[1]==2):
    print("A tie")
elif(h[0]==2) & (h[1]==3):
    print("The second man wins the game")
elif(h[0]==3) & (h[1]==1):
    print("The second man wins the game")
elif(h[0]==3) & (h[1]==2):
    print("The first man wins the game")
elif(h[0]==3) & (h[1]==3):
    print("A tie")

# 處理 i 組
if (i[0]==1) & (i[1]==1):
    print("A tie")
elif(i[0]==1) & (i[1]==2):
    print("The second man wins the game")
elif(i[0]==1) & (i[1]==3):
    print("The first man wins the game")
elif(i[0]==2) & (i[1]==1):
    print("The first man wins the game")
elif(i[0]==2) & (i[1]==2):
    print("A tie")
elif(i[0]==2) & (i[1]==3):
    print("The second man wins the game")
elif(i[0]==3) & (i[1]==1):
    print("The second man wins the game")
elif(i[0]==3) & (i[1]==2):
    print("The first man wins the game")
elif(i[0]==3) & (i[1]==3):
    print("A tie")

# 處理 j 組
if (j[0]==1) & (j[1]==1):
    print("A tie")
elif(j[0]==1) & (j[1]==2):
    print("The second man wins the game")
elif(j[0]==1) & (j[1]==3):
    print("The first man wins the game")
elif(j[0]==2) & (j[1]==1):
    print("The first man wins the game")
elif(j[0]==2) & (j[1]==2):
    print("A tie")
elif(j[0]==2) & (j[1]==3):
    print("The second man wins the game")
elif(j[0]==3) & (j[1]==1):
    print("The second man wins the game")
elif(j[0]==3) & (j[1]==2):
    print("The first man wins the game")
elif(j[0]==3) & (j[1]==3):
    print("A tie")